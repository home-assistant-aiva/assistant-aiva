"""Create an auditable closed-universe synthetic daily ledger. No network or real commerce input."""
import hashlib
import json
import shutil
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from pathlib import Path

from openpyxl import Workbook

HERE = Path(__file__).resolve().parent
ROOT = HERE if HERE.name == "pilot-complete-20260929" else HERE / "pilot-complete-20260929"
ROOT.mkdir(exist_ok=True)
XLSX = ROOT / "Ventas_demo_completas_35d_2026-08-25_a_2026-09-28.xlsx"
MANIFEST = ROOT / "manifest.json"
START = date(2026, 8, 25)
DAYS = 35
CATALOG = (
    ("DEMO-SYN-A", "Artículo sintético A", Decimal("12.50"), Decimal("5.00"), 1000),
    ("DEMO-SYN-B", "Artículo sintético B", Decimal("20.00"), Decimal("8.00"), 1000),
    ("DEMO-SYN-C", "Artículo sintético C", Decimal("7.25"), Decimal("3.50"), 1000),
)
HEADERS = ("Fecha", "Código", "Producto", "Categoría", "Cantidad", "Precio venta", "Costo", "Stock", "Descuento")
SOURCE_ID = "aiva_demo_synthetic_20260929_complete"

wb = Workbook()
ws = wb.active
ws.title = "Ventas"
ws.append(HEADERS)
wb.properties.creator = "AIVA synthetic test"
wb.properties.created = datetime(2026, 9, 29, tzinfo=timezone.utc)
wb.properties.modified = datetime(2026, 9, 29, tzinfo=timezone.utc)
stocks = {code: initial for code, _, _, _, initial in CATALOG}
revenue = cost = Decimal(0)
weeks = {"current": {"revenue": Decimal(0), "cogs": Decimal(0), "quantity": 0},
         "previous": {"revenue": Decimal(0), "cogs": Decimal(0), "quantity": 0}}
for day_index in range(DAYS):
    business_date = START + timedelta(days=day_index)
    for product_index, (code, name, price, unit_cost, _) in enumerate(CATALOG):
        # This formula defines every synthetic movement. A zero is an explicit no-sale observation.
        quantity = (day_index * 2 + product_index * 3) % 6
        stocks[code] -= quantity
        line_revenue = price * quantity
        line_cost = unit_cost * quantity
        revenue += line_revenue
        cost += line_cost
        week = "current" if date(2026, 9, 22) <= business_date <= date(2026, 9, 28) else (
            "previous" if date(2026, 9, 15) <= business_date <= date(2026, 9, 21) else None)
        if week:
            weeks[week]["revenue"] += line_revenue
            weeks[week]["cogs"] += line_cost
            weeks[week]["quantity"] += quantity
        ws.append((business_date.isoformat(), code, name, "Catálogo sintético",
                   quantity, float(price), float(unit_cost), stocks[code], 0))
wb.save(XLSX)
sha = hashlib.sha256(XLSX.read_bytes()).hexdigest()
generator_sha = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
shutil.copyfile(Path(__file__), ROOT / "generator.py")
manifest = {
    "synthetic": True,
    "complete_by_construction": True,
    "closed_universe": "Only the three catalog products exist; the formula emits the complete movement for every product on every business date, including zero-sale days. No external input is read.",
    "generator": "generator.py",
    "generator_sha256": generator_sha,
    "file_name": XLSX.name,
    "sha256": sha,
    "bytes": XLSX.stat().st_size,
    "source_id": SOURCE_ID,
    "timezone": "America/Argentina/Buenos_Aires",
    "price_semantics": "final_net",
    "gross_price_semantics": "Gross equals final net because every discount is zero.",
    "discount_semantics": "zero on all rows",
    "period_start": START.isoformat(),
    "period_end": (START + timedelta(days=DAYS - 1)).isoformat(),
    "product_codes": [row[0] for row in CATALOG],
    "dates": DAYS,
    "rows": DAYS * len(CATALOG),
    "one_observation_per_product_day": True,
    "daily_snapshot_complete_basis": "Cartesian product of closed synthetic catalog and 35 consecutive business dates; generator has no omitted transactions or external source.",
    "totals": {"net_revenue": str(revenue), "cogs": str(cost), "margin": str(revenue - cost)},
    "weekly": {
        "current_period": ["2026-09-22", "2026-09-28"],
        "previous_period": ["2026-09-15", "2026-09-21"],
        "current": {key: str(value) for key, value in weeks["current"].items()},
        "previous": {key: str(value) for key, value in weeks["previous"].items()},
    },
}
MANIFEST.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps({"sha256": sha, "rows": manifest["rows"], "current": manifest["weekly"]["current"], "previous": manifest["weekly"]["previous"]}))
